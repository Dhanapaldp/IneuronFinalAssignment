package in.spartan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.spartan.model.Employee;
import in.spartan.repo.IEmployeeRepo;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	
	@Autowired
	private IEmployeeRepo repo;
	
	@Override
	public String saveEmployee(Employee employee) {
		Integer id = repo.save(employee).getId();
		if(id!=-1)
		   return "Succesfully registered with given id::"+id;
		else
			return "Registration failed";
	}

}
