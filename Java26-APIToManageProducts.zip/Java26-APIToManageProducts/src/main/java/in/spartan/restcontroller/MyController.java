package in.spartan.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.spartan.model.Product;
import in.spartan.service.IProductService;

@RestController
@RequestMapping("/api")
public class MyController {

	@Autowired
	private IProductService service;
	
	@PostMapping("/register")
	public ResponseEntity<String> registerEmployee(@RequestBody Product product){
		String body = service.saveEmployee(product);
		return new ResponseEntity<String>(body,HttpStatus.OK);
	}
	
	
	@GetMapping("/findall")
	public ResponseEntity<?> getAllProduct(){
		try {
			 List<Product> list = service.getAllProduct();
			return new ResponseEntity<List<Product>>(list,HttpStatus.OK);
		}
		catch(Exception e) {
		   return  new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/find/{id}")
	public ResponseEntity<?> getProductById(@PathVariable Integer id){
		try {
			Product product = service.getProductById(id);
			return new ResponseEntity<Product>(product,HttpStatus.OK);
		}
		catch(Exception e) {
		   return  new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/update")
	public ResponseEntity<?> updateProduct(@RequestBody Product product){
		try {
			String status = service.updateProduct(product);
			return new ResponseEntity<String>(status,HttpStatus.OK);
		}
		catch(Exception e) {
		   return  new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@DeleteMapping("/delete")
	public ResponseEntity<?> deleteProductById(@RequestParam Integer id){
		try {
			String body = service.deleteProduct(id);
			return new ResponseEntity<String>(body,HttpStatus.OK);
		}
		catch(Exception e) {
		   return  new ResponseEntity<String>("Record Not found for given id::"+id,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
