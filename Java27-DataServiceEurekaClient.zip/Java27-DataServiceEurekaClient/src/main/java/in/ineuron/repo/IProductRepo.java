package in.ineuron.repo;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.model.Product;

public interface IProductRepo extends CrudRepository<Product, Integer> {

}
