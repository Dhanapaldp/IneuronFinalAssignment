package in.interfacekeyword;

public interface InterfaceKeyword {
	
	//By default public static final
	int a=30;
	
	//There is no constructor in interface
	//Only abstract methods and 'public abstract' is no need to give
	void m1();
	
	//To give the implementation of interface we use 'implement ' keyword
	//It supports multiple inheritance
	//The implementation class may be a abstract class or concrete class
	//It can implement several interfaces

}
