package in.ineuron.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.dto.Student;
import in.ineuron.util.JdbcUtil;

//Persistence logic using JDBC API
public class StudentDaoImpl implements IStudentDao {

	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;

	@Override
	public List<Student> searchStudent() {
		
		List<Student> list=new ArrayList();
		String sqlSelectQuery = "select * from student ";
		Student student = null;

		try {
			connection = JdbcUtil.getConnection();

			if (connection != null)
				pstmt = connection.prepareStatement(sqlSelectQuery);
				resultSet = pstmt.executeQuery();
	

			if (resultSet != null) {

				while (resultSet.next()) {
					student = new Student();

					// copy resultSet data to student object
					student.setSid(resultSet.getInt(1));
					student.setSname(resultSet.getString(2));
					student.setSage(resultSet.getInt(3));
					student.setSaddress(resultSet.getString(4));

					list.add(student);
				}

			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return list;
	}



}
