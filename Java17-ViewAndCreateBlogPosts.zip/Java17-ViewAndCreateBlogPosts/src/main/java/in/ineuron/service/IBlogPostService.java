package in.ineuron.service;

import java.util.List;

import in.ineuron.model.BlogPost;

public interface IBlogPostService {

	public String createPost(BlogPost post);
	public List<BlogPost> viewPosts();
}
