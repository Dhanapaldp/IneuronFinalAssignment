package in.ineuron.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.Book;

public interface IBookRepo extends JpaRepository<Book, Integer> {

}
