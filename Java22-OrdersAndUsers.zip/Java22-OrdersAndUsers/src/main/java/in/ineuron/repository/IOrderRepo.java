package in.ineuron.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.entity.Order;

public interface IOrderRepo extends JpaRepository<Order, Long> {
    List<Order> findByUser_Id(Long userId);
}
