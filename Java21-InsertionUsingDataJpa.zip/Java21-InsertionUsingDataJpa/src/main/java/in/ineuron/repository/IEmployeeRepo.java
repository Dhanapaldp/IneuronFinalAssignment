package in.ineuron.repository;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.model.Employee;

public interface IEmployeeRepo extends CrudRepository<Employee, Integer> {

}
