package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.model.Employee;
import in.ineuron.repository.IEmployeeRepo;

@Service	
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeRepo repo;
	
	@Override
	public String registerEmployee(Employee employee) {
		Employee emp = repo.save(employee);
		return "Registered successfully with Id :"+emp.getId();
	}

}
