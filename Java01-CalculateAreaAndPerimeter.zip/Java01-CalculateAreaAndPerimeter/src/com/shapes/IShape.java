package com.shapes;

public interface IShape {
	
	public Double calculateArea() ;
	public Double calculatePerimeter();
}
