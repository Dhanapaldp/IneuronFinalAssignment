package com.shapes;

public class Triangle implements IShape {

	private Double base;
	private Double height;
	private Double hypoSide;
	
	
	public Triangle(Double base, Double height, Double hypoSide) {
		this.base = base;
		this.height = height;
		this.hypoSide = hypoSide;
	}

	@Override
	public Double calculateArea() {
		return ((1/2)*base*height);
	}

	@Override
	public Double calculatePerimeter() {
		return base+height+hypoSide;
	}

}
