package com.bankOffers;

import java.util.Scanner;

import com.server.Server;

public class Withdrawl extends Server{

	@Override
	public void verifyUser() {
		Scanner s=new Scanner(System.in);
		if(uid==id && upw==pw)
		{
			System.out.println("Enter the amount to be Withdraw");
			amount=s.nextDouble();

			System.out.println("Your amount is Withdrawyed successfully ");
			Balance.afterWithdraw(amount);
			System.out.println("Your bank Balance is");
			System.out.println(bankBalance);
			
			System.out.println("Thank you");
		}
		else
		{
			System.out.println("Login credentials are wrong pls check..");
		}
		
		s.close();
	}
	

}
