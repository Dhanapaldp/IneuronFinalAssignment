package com.server;

import java.util.Scanner;

public abstract class Server {
	
	    public int uid=54321;
		public int upw=12345;
		public int id;
		public int pw;
		public double amount;
		public static double bankBalance=20000;
		Scanner s=new Scanner(System.in);
		
		public void input()
		{
			System.out.println("Enter the UserID");
			id=s.nextInt();
			System.out.println("Enter the PassWord");
			pw=s.nextInt();
		}
		
		public abstract void verifyUser() ;

}
