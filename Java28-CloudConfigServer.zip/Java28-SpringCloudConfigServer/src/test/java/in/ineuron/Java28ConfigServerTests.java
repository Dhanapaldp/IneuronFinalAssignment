package in.ineuron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java28ConfigServerTests {

	@Test
	void contextLoads() {
	}

}
