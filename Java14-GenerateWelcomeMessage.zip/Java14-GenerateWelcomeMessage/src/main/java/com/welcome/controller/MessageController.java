package com.welcome.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/msgGenerator")
public class MessageController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String name= request.getParameter("name");
		String resp="Hello "+name;
		LocalTime now = LocalTime.now();
		int hours = now.getHour();
		if(hours<12)
			resp=resp+" good morning..";
		else if(hours<16)
			resp=resp+" good afternoon..";
		else if(hours <20)
			resp=resp+" good evening..";
		else
			resp=resp+" good night..";
		
		out.println("<h1 style='color:red; text-align:center;'>"+resp+"</h1>");
		
	}

}
