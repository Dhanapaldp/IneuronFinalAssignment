package in.ineuron;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.service.Calculation;

@SpringBootApplication
public class Java25SpringAoPtoLogMethodCallsApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Java25SpringAoPtoLogMethodCallsApplication.class, args);
		
		Calculation bean = run.getBean(Calculation.class);
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter num1");
		double num1=scan.nextDouble();
		System.out.println("Enter num2");
		double num2=scan.nextDouble();
		
		Double result1 = bean.addNumbers(num1, num2);
		System.out.println("The addition of two numbers is ::"+result1);
		
		Double result2 = bean.multiplyNumbers(num1, num2);
		System.out.println("The multiplicationn of two numbers is ::"+result2);
		
		scan.close();
	}

}
