package in.main;

import in.threads.FirstThread;
import in.threads.SecondThread;

public class TestApp {
	
	public static void main(String[] args) {
		
		Thread thread1=new Thread(new SecondThread());
		Thread thread2=new Thread(new FirstThread());
		
		thread1.start();
		thread2.start();
		
	
	}

}
