package in.ineuron.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import in.ineuron.model.CricketerBO;
import in.ineuron.util.Utility;

public class CricketerDaoLayer {
	
	Session session=null;
	
	public String updateCricketer(CricketerBO cricketer) {
		Transaction transaction=null;
		boolean flag=false;

		session=Utility.getSession();
		try {
			if(session!=null) {
				transaction=session.beginTransaction();
				session.merge(cricketer);
				flag=true;
			}
		}catch(HibernateException he) {
			he.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(flag) {
				transaction.commit();
				System.out.println("updated successfully");
			}else {
				transaction.rollback();
				System.out.println("updation failed, Try again");
			
			}
		}
		return "failure";
	}
	public CricketerBO getDatas(Integer id) {
		
		Session session=null;
		CricketerBO bo =null;
		
		try {
			session=Utility.getSession();
			bo = session.get(CricketerBO.class, id);
			
		}catch(HibernateException he) {
			he.getMessage();
		}
		
		return bo;
	}
	

}
