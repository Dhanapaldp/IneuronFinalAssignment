package in.spartan.repo;


import org.springframework.data.repository.PagingAndSortingRepository;

import in.spartan.model.Employee;

public interface IEmployeeRepo extends PagingAndSortingRepository<Employee, Integer>{

}
