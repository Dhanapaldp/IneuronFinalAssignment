package in.ineuron.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "cricketerbo")
public class CricketerBO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String name;
	private String franchise;
	private String team;
	
	
	
	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getFranchise() {
		return franchise;
	}



	public void setFranchise(String franchise) {
		this.franchise = franchise;
	}



	public String getTeam() {
		return team;
	}



	public void setTeam(String team) {
		this.team = team;
	}



	@Override
	public String toString() {
		return "Cricketer [id=" + id + ", name=" + name + ", franchise=" + franchise + ", team=" + team + "]";
	}
	
	

}
