package in.ineuron.main;

import in.ineuron.dao.CricketerDaoLayer;


public class TestApp {
	
	public static void main(String[] args) {		
		CricketerDaoLayer cric=new CricketerDaoLayer();
		cric.getDatas();
	}

}
