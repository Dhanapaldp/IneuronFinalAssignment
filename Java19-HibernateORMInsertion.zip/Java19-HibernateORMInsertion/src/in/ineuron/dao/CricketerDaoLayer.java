package in.ineuron.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import in.ineuron.model.CricketerBO;
import in.ineuron.util.Utility;

public class CricketerDaoLayer {
	
	Session session=null;
	
	@SuppressWarnings("finally")
	public int registerCricketer(CricketerBO cricketer) {
		Transaction transaction=null;
		boolean flag=false;
        Integer id=-1;
		
		session=Utility.getSession();
		try {
			if(session!=null) {
				transaction=session.beginTransaction();
				id  = (Integer) session.save(cricketer);
				flag=true;
			}
		}catch(HibernateException he) {
			he.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(flag) {
				transaction.commit();
				System.out.println("Object inserted into the database");
				return id;
			}else {
				transaction.rollback();
				System.out.println("Insertion failed");
				return id;
			
			}
		}
		
	}
	public void getDatas(Integer id) {
		
		Session session=null;

		try {
			session=Utility.getSession();
			CricketerBO bo = session.get(CricketerBO.class, id);
			System.out.println(bo);	
		}catch(HibernateException he)
		{
			he.getMessage();
		}catch(Exception e) {
			e.getLocalizedMessage();
		}
		finally {
			Utility.closeSession(session);
			Utility.closeSessionFactory();
		}
		
		
	}
	

}
